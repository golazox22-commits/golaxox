JERSEY IMAGE MAPPING

Use these local image paths in the website:

/images/manchester-city.jpg       -> Manchester City
/images/al-nassr.jpg              -> Al Nassr
/images/liverpool.jpg             -> Liverpool
/images/bayern-munich.jpg         -> Bayern Munich
/images/real-madrid-home.jpg      -> Real Madrid (Home)
/images/arsenal.jpg               -> Arsenal
/images/manchester-united.jpg     -> Manchester United
/images/arsenal-red.jpg           -> Arsenal (Red alternate)
/images/juventus.jpg              -> Juventus
/images/real-madrid-away.jpg      -> Real Madrid (Away)
/images/barcelona.jpg             -> Barcelona
/images/psg.jpg                   -> Paris Saint-Germain

IMPORTANT:
- Keep the image aspect ratio.
- Do not replace these images with external images.
- Rename the extracted folder to "images" when uploading it to GitHub.
